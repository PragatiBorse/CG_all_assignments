/*write an application to determine the length of the string str="Hello World"*/
package com.stringbuffer_builder;

public class FindLength {

	public static void main(String[] args) {

		String str="Hello World";
		int n=str.length();
		System.out.println("Length is: "+str.length());
		
        
	}

}
