package com.stringbuffer_builder;

public class JoinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Hello";
		String s2=" How Are You?";
		
		System.out.println(s1.concat(s2));
	}

}
